// সিন F — download + সতর্কতা (cue 6 + 7) · UI Button Flow → Glass Cards
import React from 'react';
import {AbsoluteFill} from 'remotion';
import {theme} from '../theme';
import {SceneShell} from '../components/layers';
import {ease, lerp, Rise, useAbs, useSpringAt, Words} from '../components/motion';
import {IconAlert, IconCheck, IconDownload, IconLock, Mark, Pill, surfaceCard} from '../components/art';
import type {SfxEvent} from '../components/Sfx';
import {LEAD, sceneRange, when} from '../timing';

export const rangeF = sceneRange(6, 7);

const T = {
  card: rangeF.from - LEAD + 2,
  down: when(6, 'download'),
  use: when(6, 'ব্যবহার'),
  note: when(6, 'তবে'),
  feat: when(6, 'feature'),
  login: when(6, 'login'),
  usage: when(6, 'usage'),
  limit: when(7, 'limit'),
};
const F1_OUT = T.note - 8;

export const sfxF: SfxEvent[] = [
  {at: T.card, name: 'pop', vol: 0.8},
  {at: T.down + 6, name: 'click'},
  {at: T.down + 40, name: 'chime', vol: 0.8},
  {at: T.use + 1, name: 'pop', rate: 1.05},
  {at: T.note + 1, name: 'swish'},
  {at: T.login + 1, name: 'pop'},
  {at: T.usage + 1, name: 'pop', rate: 1.1},
  {at: T.limit + 4, name: 'thud', vol: 0.7},
];

const ARC = 0.72; // গেজের শেষ মান (ছবির মতো ভরাট), সংখ্যা স্ক্রিনে লেখা নেই

const Gauge: React.FC<{p: number}> = ({p}) => {
  const r = 120;
  const cx = 160;
  const cy = 170;
  const a = (deg: number) => ({x: cx + r * Math.cos((deg * Math.PI) / 180), y: cy + r * Math.sin((deg * Math.PI) / 180)});
  const s = a(180);
  const e = a(360);
  const path = `M ${s.x} ${s.y} A ${r} ${r} 0 0 1 ${e.x} ${e.y}`;
  const needleDeg = 180 + 180 * p * ARC / 1;
  const n = a(needleDeg);
  return (
    <svg width="320" height="210" viewBox="0 0 320 210" fill="none">
      <path d={path} stroke={theme.colors.washHi} strokeWidth="26" strokeLinecap="round" />
      <path d={path} stroke={theme.colors.accent} strokeWidth="26" strokeLinecap="round" pathLength={1} strokeDasharray="1" strokeDashoffset={1 - p * ARC} />
      <line x1={cx} y1={cy} x2={cx + (n.x - cx) * 0.78} y2={cy + (n.y - cy) * 0.78} stroke={theme.colors.text} strokeWidth="9" strokeLinecap="round" />
      <circle cx={cx} cy={cy} r="15" fill={theme.colors.text} />
    </svg>
  );
};

export const SceneF: React.FC = () => {
  const f = useAbs();
  const press = ease(f, T.down + 4, T.down + 9, 0, 1) * (1 - ease(f, T.down + 9, T.down + 18, 0, 1));
  const prog = ease(f, T.down + 10, T.down + 40, 0, 1, theme.ease.inOut);
  const done = ease(f, T.down + 38, T.down + 46, 0, 1);
  const usageP = ease(f, T.usage, T.limit + 12, 0, 1, theme.ease.inOut);
  const glassCard = (extra?: React.CSSProperties): React.CSSProperties => ({
    width: 520,
    height: 380,
    borderRadius: 48,
    background: `linear-gradient(160deg, ${theme.colors.washHi}, ${theme.colors.wash})`,
    border: `1px solid ${theme.colors.lineStrong}`,
    backdropFilter: 'blur(24px)',
    boxShadow: theme.shadow.card,
    position: 'relative',
    ...extra,
  });

  return (
    <SceneShell variant={5}>
      {/* --- F1: download --- */}
      <div style={{position: 'absolute', left: 140, top: 250}}>
        <Rise at={T.card} dx={-60} dy={40} cfg="smooth" out={F1_OUT} breathe={0.006}>
          <div style={{...surfaceCard({width: 560, height: 560, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 64})}}>
            <Mark kind="cube" size={380} id="f0" />
          </div>
        </Rise>
      </div>
      <div style={{position: 'absolute', left: 770, top: 270}}>
        <Rise at={T.down - 4} dx={60} dy={0} cfg="snappy" out={F1_OUT}>
          <div
            style={{
              width: 560,
              height: 128,
              borderRadius: 40,
              background: theme.colors.primary,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 22,
              fontFamily: theme.fonts.display,
              fontSize: 58,
              fontWeight: 700,
              lineHeight: 1.3,
              letterSpacing: 0,
              color: theme.colors.white,
              transform: `scale(${1 - press * 0.06})`,
              boxShadow: `0 24px 60px -16px ${theme.colors.glow}, 0 0 0 ${press * 18}px ${theme.colors.primarySoft}`,
            }}
          >
            {done > 0.5 ? <IconCheck size={58} color={theme.colors.white} /> : <IconDownload size={58} color={theme.colors.white} />}
            download
          </div>
        </Rise>
      </div>
      <div style={{position: 'absolute', left: 770, top: 440}}>
        <Rise at={T.down + 6} dy={20} cfg="smooth" out={F1_OUT}>
          <div style={{width: 560, height: 18, borderRadius: 9, background: theme.colors.washHi, overflow: 'hidden'}}>
            <div style={{width: '100%', height: '100%', borderRadius: 9, background: theme.colors.accent, transform: `scaleX(${prog})`, transformOrigin: '0% 50%'}} />
          </div>
        </Rise>
      </div>
      {/* ব্যবহারের নমুনা: অ্যাভাটার · ব্যানার · অ্যাপ আইকন */}
      <div style={{position: 'absolute', left: 770, top: 540, display: 'flex', alignItems: 'center', gap: 30}}>
        <Rise at={T.use} dy={50} from={0.8} cfg="bouncy" out={F1_OUT}>
          <div style={{...surfaceCard({width: 140, height: 140, borderRadius: 70, display: 'flex', alignItems: 'center', justifyContent: 'center'})}}>
            <Mark kind="cube" size={92} id="f1" />
          </div>
        </Rise>
        <Rise at={T.use + 5} dy={50} from={0.8} cfg="bouncy" out={F1_OUT}>
          <div style={{...surfaceCard({width: 220, height: 140, borderRadius: 32, display: 'flex', alignItems: 'center', justifyContent: 'center'})}}>
            <Mark kind="cube" size={92} id="f2" />
          </div>
        </Rise>
        <Rise at={T.use + 10} dy={50} from={0.8} cfg="bouncy" out={F1_OUT}>
          <div style={{...surfaceCard({width: 140, height: 140, borderRadius: 38, display: 'flex', alignItems: 'center', justifyContent: 'center'})}}>
            <Mark kind="cube" size={92} id="f3" />
          </div>
        </Rise>
      </div>

      {/* --- F2: সতর্কতা --- */}
      <AbsoluteFill style={{alignItems: 'center', justifyContent: 'flex-start', paddingTop: 96}}>
        <Rise at={T.note} dy={30} cfg="snappy">
          <Pill size={52} bg={theme.colors.accentSoft} border={theme.colors.accent} color={theme.colors.accent}>
            <IconAlert size={56} color={theme.colors.accent} />
            তবে মনে রেখো
          </Pill>
        </Rise>
        <div style={{marginTop: 20}}>
          <Words toks={['কিছু', {t: 'feature', color: theme.colors.accent}]} at={T.feat} per={5} size={130} />
        </div>
      </AbsoluteFill>
      <div style={{position: 'absolute', left: 160, top: 520}}>
        <Rise at={T.login} dy={70} from={0.9} cfg="snappy" breathe={0.006}>
          <div style={glassCard()}>
            <div style={{position: 'absolute', left: 0, right: 0, top: 56, display: 'flex', justifyContent: 'center'}}>
              <div style={{width: 168, height: 168, borderRadius: '50%', background: theme.colors.primarySoft, border: `2px solid ${theme.colors.primary}`, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                <IconLock size={96} color={theme.colors.primaryLight} />
              </div>
            </div>
            <div style={{position: 'absolute', left: 0, right: 0, bottom: 44, textAlign: 'center', fontFamily: theme.fonts.display, fontSize: 80, fontWeight: 700, lineHeight: 1.3, letterSpacing: 0, color: theme.colors.text}}>
              login
            </div>
          </div>
        </Rise>
      </div>
      <div style={{position: 'absolute', left: 760, top: 520}}>
        <Rise at={T.usage} dy={70} from={0.9} cfg="snappy" breathe={0.006}>
          <div style={glassCard()}>
            <div style={{position: 'absolute', left: 100, top: 40}}>
              <Gauge p={usageP} />
            </div>
            <div style={{position: 'absolute', left: 0, right: 0, bottom: 44, textAlign: 'center', fontFamily: theme.fonts.display, fontSize: 80, fontWeight: 700, lineHeight: 1.3, letterSpacing: 0, color: theme.colors.text}}>
              usage limit
            </div>
          </div>
        </Rise>
      </div>
    </SceneShell>
  );
};
