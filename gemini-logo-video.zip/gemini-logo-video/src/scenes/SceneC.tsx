// সিন C — Gemini সার্চ + brand নাম লেখা (cue 3) · Glossy UI Mockup
import React from 'react';
import {Img, staticFile} from 'remotion';
import {theme} from '../theme';
import {SceneShell} from '../components/layers';
import {ease, lerp, Rise, useAbs, useSpringAt, Words} from '../components/motion';
import {IconSearch, surfaceCard} from '../components/art';
import type {SfxEvent} from '../components/Sfx';
import {sceneRange, when} from '../timing';

export const rangeC = sceneRange(3, 3);

const T = {
  win: rangeC.from - 3,
  gem: when(3, 'Gemini'),
  search: when(3, 'search'),
  next: when(3, 'এরপর'),
  brand: when(3, 'brand'),
  ask: when(3, 'কেমন'),
};

export const sfxC: SfxEvent[] = [
  {at: T.win, name: 'pop', vol: 0.8},
  {at: T.gem + 1, name: 'chime'},
  {at: T.search, name: 'click'},
  {at: T.next, name: 'swish', vol: 0.8},
  {at: T.brand + 1, name: 'pop'},
  {at: T.ask + 1, name: 'pop', rate: 1.08},
];

const WIN = {x: 120, y: 140, w: 1200, h: 800};
const BAR = 96;
const TYPED = 'Gemini AI';

/** Gemini লোগো — বিকৃত না করে সাদা কার্ডে বসানো (ছবির সাদা কিনারা কার্ডের সাথে মিশে যায়) */
export const GeminiLogo: React.FC<{size: number; radius?: number}> = ({size, radius = size * 0.22}) => (
  <div
    style={{
      width: size,
      height: size,
      borderRadius: radius,
      overflow: 'hidden',
      background: theme.colors.white,
      boxShadow: theme.shadow.float,
    }}
  >
    <Img src={staticFile('gemini-logo.jpg')} style={{width: '100%', height: '100%', objectFit: 'cover', transform: 'scale(1.12)'}} />
  </div>
);

export const SceneC: React.FC = () => {
  const f = useAbs();
  const typed = Math.floor(ease(f, T.gem, T.gem + 18, 0, TYPED.length + 0.99, theme.ease.out));
  const caretOn = Math.floor(f / 8) % 2 === 0;
  const press = ease(f, T.search, T.search + 5, 0, 1) * (1 - ease(f, T.search + 5, T.search + 14, 0, 1));
  const found = ease(f, T.search, T.search + 10, 0, 1) * (1 - ease(f, T.search + 18, T.search + 40, 0, 1));
  const view2 = ease(f, T.next, T.next + 8, 0, 1);
  const float = Math.sin(f / 30) * 5;

  return (
    <SceneShell variant={2}>
      <div style={{position: 'absolute', left: WIN.x, top: WIN.y}}>
        <Rise at={T.win} dy={70} from={0.92} cfg="smooth" breathe={0.004}>
          <div style={{...surfaceCard({width: WIN.w, height: WIN.h, position: 'relative', overflow: 'hidden', borderRadius: 48})}}>
            {/* টপ বার */}
            <div
              style={{
                position: 'absolute',
                left: 0,
                top: 0,
                width: WIN.w,
                height: BAR,
                background: theme.colors.wash,
                borderBottom: `1px solid ${theme.colors.line}`,
              }}
            >
              <div style={{position: 'absolute', left: 38, top: 39, display: 'flex', gap: 12}}>
                {[0, 1, 2].map((i) => (
                  <div key={i} style={{width: 18, height: 18, borderRadius: '50%', background: theme.colors.lineStrong}} />
                ))}
              </div>
              <div
                style={{
                  position: 'absolute',
                  left: 150,
                  top: 18,
                  width: 900,
                  height: 60,
                  borderRadius: 30,
                  background: theme.colors.bg,
                  border: `1px solid ${theme.colors.line}`,
                  display: 'flex',
                  alignItems: 'center',
                  paddingLeft: 24,
                  gap: 16,
                }}
              >
                <IconSearch size={34} color={theme.colors.textDim} />
                <div style={{fontFamily: theme.fonts.body, fontSize: 34, fontWeight: 600, color: theme.colors.text, lineHeight: 1.3, letterSpacing: 0}}>
                  {TYPED.slice(0, typed)}
                  <span style={{opacity: caretOn ? 1 : 0, color: theme.colors.primaryLight}}>|</span>
                </div>
                <div
                  style={{
                    position: 'absolute',
                    right: 8,
                    top: 8,
                    width: 44,
                    height: 44,
                    borderRadius: '50%',
                    background: theme.colors.primary,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    transform: `scale(${1 - press * 0.16})`,
                  }}
                >
                  <IconSearch size={26} color={theme.colors.white} />
                </div>
              </div>
            </div>

            {/* কনটেন্ট ১: লোগো রিভিল */}
            <div style={{position: 'absolute', left: 0, top: BAR, width: WIN.w, height: WIN.h - BAR}}>
              <div style={{position: 'absolute', left: (WIN.w - 360) / 2, top: 120 + float}}>
                <Rise at={T.gem} dy={50} from={0.6} cfg="bouncy" out={T.next - 4}>
                  <div style={{borderRadius: 80, boxShadow: `0 0 ${70 * found}px ${theme.colors.glow}`}}>
                    <GeminiLogo size={360} radius={80} />
                  </div>
                </Rise>
              </div>
              <div style={{position: 'absolute', left: 0, width: WIN.w, top: 520, display: 'flex', justifyContent: 'center'}}>
                <Rise at={T.gem + 6} dy={24} out={T.next - 4}>
                  <div style={{fontFamily: theme.fonts.display, fontSize: 64, fontWeight: 700, lineHeight: 1.3, color: theme.colors.text, letterSpacing: 0}}>
                    Gemini
                  </div>
                </Rise>
              </div>
            </div>

            {/* কনটেন্ট ২: চ্যাট */}
            <div style={{position: 'absolute', left: 0, top: BAR, width: WIN.w, height: WIN.h - BAR, opacity: view2}}>
              <div style={{position: 'absolute', left: 60, top: 38}}>
                <Rise at={T.next} dx={-40} dy={0} cfg="snappy">
                  <div style={{display: 'flex', alignItems: 'center', gap: 22}}>
                    <GeminiLogo size={84} radius={24} />
                    <span style={{fontFamily: theme.fonts.display, fontSize: 46, fontWeight: 700, lineHeight: 1.3, color: theme.colors.text}}>Gemini</span>
                  </div>
                </Rise>
              </div>
              <div style={{position: 'absolute', right: 60, top: 190}}>
                <Rise at={T.brand} dx={60} dy={20} from={0.9} cfg="snappy" origin="100% 50%">
                  <div
                    style={{
                      background: theme.colors.primary,
                      borderRadius: 54,
                      borderBottomRightRadius: 16,
                      padding: '30px 54px 34px',
                      minWidth: 560,
                      boxShadow: `0 24px 60px -18px ${theme.colors.glow}`,
                    }}
                  >
                    <Words toks={['brand', 'নাম']} at={T.brand} per={4} size={58} color={theme.colors.white} align="flex-start" lh={1.35} />
                    <Words toks={['কেমন', 'logo', 'চাও?']} at={T.ask} per={4} size={58} color={theme.colors.white} align="flex-start" lh={1.35} />
                  </div>
                </Rise>
              </div>
              {/* ইনপুট বার */}
              <div style={{position: 'absolute', left: 60, right: 60, bottom: 44}}>
                <Rise at={T.next + 4} dy={40} cfg="smooth">
                  <div
                    style={{
                      height: 92,
                      borderRadius: 46,
                      background: theme.colors.bg,
                      border: `1px solid ${theme.colors.line}`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '0 14px 0 40px',
                    }}
                  >
                    <span style={{opacity: caretOn ? 1 : 0, color: theme.colors.primaryLight, fontSize: 40, fontFamily: theme.fonts.body}}>|</span>
                    <div
                      style={{
                        width: 64,
                        height: 64,
                        borderRadius: '50%',
                        background: theme.colors.white,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <IconSend2 />
                    </div>
                  </div>
                </Rise>
              </div>
            </div>
          </div>
        </Rise>
      </div>
    </SceneShell>
  );
};

const IconSend2: React.FC = () => (
  <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke={theme.colors.bg} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 19V5M6.5 10.5L12 5l5.5 5.5" />
  </svg>
);
