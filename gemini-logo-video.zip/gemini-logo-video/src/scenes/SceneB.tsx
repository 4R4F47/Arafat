// সিন B — সমস্যা বনাম সমাধান (cue 2) · Before/After Split → "প্রথমে Google"
import React from 'react';
import {AbsoluteFill} from 'remotion';
import {theme} from '../theme';
import {SceneShell} from '../components/layers';
import {ease, lerp, Rise, useAbs, useSpringAt, Words} from '../components/motion';
import {IconBolt, IconCheck, IconCoin, IconPerson, IconSearch, Pill, surfaceCard} from '../components/art';
import type {SfxEvent} from '../components/Sfx';
import {LEAD, sceneRange, when} from '../timing';

export const rangeB = sceneRange(2, 2);

const T = {
  // বাম কার্ড সিনের শুরুতেই ঢোকে (ট্রানজিশনের পর ফাঁকা পর্দা এড়াতে); দাগ/ডান কার্ড কথার সময়ে
  left: Math.min(when(2, 'designerকে'), rangeB.from - LEAD + 6),
  slash: when(2, 'টাকা'),
  right: when(2, 'এই trickটা'),
  ok: when(2, 'তোমার জন্য'),
  google: when(2, 'প্রথমে'),
};
const CARDS_OUT = T.google - 8;

export const sfxB: SfxEvent[] = [
  {at: T.left + 1, name: 'pop'},
  {at: T.slash, name: 'click'},
  {at: T.right + 1, name: 'pop', rate: 1.08},
  {at: T.ok + 1, name: 'click', rate: 1.1, vol: 0.8},
  {at: T.google + 1, name: 'swish'},
];

const CW = 620;
const CH = 560;

export const SceneB: React.FC = () => {
  const f = useAbs();
  const slash = ease(f, T.slash, T.slash + 12, 0, 1, theme.ease.out);
  const dim = ease(f, T.slash + 6, T.slash + 18, 0, 1);
  const rightP = useSpringAt(T.right, 'smooth');
  const okP = useSpringAt(T.ok, 'bouncy');
  const gP = useSpringAt(T.google, 'bouncy');
  const under = ease(f, T.google + 6, T.google + 24, 0, 1);
  const bolt = 1 + Math.sin(f / 18) * 0.04;

  return (
    <SceneShell variant={1}>
      {/* বাম: designer */}
      <div style={{position: 'absolute', left: 80, top: 250}}>
        <Rise at={T.left} dx={-120} dy={0} out={CARDS_OUT} cfg="smooth">
          <div
            style={{
              ...surfaceCard({width: CW, height: CH, position: 'relative', overflow: 'hidden'}),
              opacity: lerp(dim, 1, 0.55),
            }}
          >
            <div style={{position: 'absolute', left: 36, top: 34}}>
              <Pill size={38}>designer</Pill>
            </div>
            <div style={{position: 'absolute', left: 0, right: 0, top: 150, display: 'flex', justifyContent: 'center'}}>
              <IconPerson size={210} color={theme.colors.textDim} sw={1.4} />
            </div>
            <div style={{position: 'absolute', left: 60, right: 60, bottom: 52, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 24}}>
              <IconCoin size={84} color={theme.colors.accent} />
              <span style={{fontFamily: theme.fonts.display, fontSize: 72, fontWeight: 700, lineHeight: 1.3, color: theme.colors.text}}>টাকা</span>
            </div>
            {/* কাটা দাগ */}
            <svg width={CW} height={CH} style={{position: 'absolute', left: 0, top: 0}}>
              <path
                d={`M 70 70 L ${CW - 70} ${CH - 70}`}
                stroke={theme.colors.accent}
                strokeWidth="16"
                strokeLinecap="round"
                pathLength={1}
                strokeDasharray="1"
                strokeDashoffset={1 - slash}
              />
            </svg>
          </div>
        </Rise>
      </div>

      {/* ডান: trick */}
      <div style={{position: 'absolute', left: 740, top: 250}}>
        <Rise at={T.right} dx={120} dy={0} out={CARDS_OUT} cfg="smooth">
          <div
            style={{
              ...surfaceCard({width: CW, height: CH, position: 'relative'}),
              border: `2px solid ${okP > 0.05 ? theme.colors.primary : theme.colors.line}`,
              boxShadow: `${theme.shadow.card}, 0 0 ${60 * Math.min(1, okP)}px ${theme.colors.glow}`,
            }}
          >
            <div style={{position: 'absolute', left: 36, top: 34}}>
              <Pill size={38} bg={theme.colors.primary} border={theme.colors.primary} color={theme.colors.white}>
                trick
              </Pill>
            </div>
            <div style={{position: 'absolute', left: 0, right: 0, top: 150, display: 'flex', justifyContent: 'center'}}>
              <div
                style={{
                  width: 210,
                  height: 210,
                  borderRadius: '50%',
                  background: theme.colors.primarySoft,
                  border: `2px solid ${theme.colors.primary}`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  transform: `scale(${lerp(rightP, 0.7, 1) * bolt})`,
                }}
              >
                <IconBolt size={120} color={theme.colors.primaryLight} />
              </div>
            </div>
            <div style={{position: 'absolute', left: 60, right: 60, bottom: 52, textAlign: 'center'}}>
              <span style={{fontFamily: theme.fonts.display, fontSize: 72, fontWeight: 700, lineHeight: 1.3, color: theme.colors.text}}>তোমার জন্য</span>
            </div>
            {/* টিক ব্যাজ */}
            <div
              style={{
                position: 'absolute',
                right: 34,
                top: 28,
                width: 84,
                height: 84,
                borderRadius: '50%',
                background: theme.colors.accent,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                opacity: Math.min(1, okP),
                transform: `scale(${lerp(okP, 0.3, 1)})`,
              }}
            >
              <IconCheck size={52} color={theme.colors.onAccent} />
            </div>
          </div>
        </Rise>
      </div>

      {/* প্রথমে Google */}
      <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center'}}>
        <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14}}>
          <Rise at={T.google} dy={30} cfg="snappy">
            <Pill size={52} bg={theme.colors.accentSoft} border={theme.colors.accent} color={theme.colors.accent}>
              প্রথমে
            </Pill>
          </Rise>
          <div
            style={{
              fontFamily: theme.fonts.display,
              fontSize: 250,
              fontWeight: 700,
              lineHeight: 1.2,
              letterSpacing: 0,
              color: theme.colors.text,
              opacity: Math.min(1, gP),
              transform: `translateY(${lerp(gP, 60, 0)}px) scale(${lerp(gP, 0.85, 1)})`,
            }}
          >
            Google
          </div>
          <div style={{display: 'flex', alignItems: 'center', gap: 22, width: 640}}>
            <div style={{flex: 1, height: 14, borderRadius: 7, background: theme.colors.primary, transform: `scaleX(${under})`, transformOrigin: '0% 50%'}} />
            <div style={{opacity: under}}>
              <IconSearch size={64} color={theme.colors.primaryLight} />
            </div>
          </div>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
