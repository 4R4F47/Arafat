// সিন A — হুক (cue 1) · Kinetic Typography + খালি লোগো-টাইল
import React from 'react';
import {AbsoluteFill} from 'remotion';
import {theme} from '../theme';
import {SceneShell} from '../components/layers';
import {ease, lerp, Rise, useAbs, useSpringAt, Words} from '../components/motion';
import {IconChannel, IconStore, Pill} from '../components/art';
import type {SfxEvent} from '../components/Sfx';
import {sceneRange, when} from '../timing';

export const rangeA = sceneRange(1, 1);

const T = {
  tile: 0,
  qmark: 4,
  chip1: when(1, 'YouTube'),
  chip2: when(1, 'নিজের'),
  you: when(1, 'তোমার'),
  head: when(1, 'professional'),
  ask: when(1, 'দরকার'),
};

export const sfxA: SfxEvent[] = [
  {at: 1, name: 'thud', vol: 0.8},
  {at: T.you + 1, name: 'swish', vol: 0.7},
  {at: T.chip1 + 1, name: 'pop'},
  {at: T.chip2 + 1, name: 'pop', rate: 1.1},
  {at: T.head + 1, name: 'swish'},
  {at: T.ask + 1, name: 'pop', rate: 0.92},
];

const TILE = 340;

export const SceneA: React.FC = () => {
  const f = useAbs();
  const tileP = useSpringAt(T.tile, 'smooth');
  const q = useSpringAt(T.qmark, 'bouncy');
  const askP = useSpringAt(T.ask, 'bouncy');
  const pulse = ease(f, T.ask, T.ask + 10, 0, 1) * (1 - ease(f, T.ask + 10, T.ask + 24, 0, 1));
  const breathe = 1 + Math.sin(f / 22) * 0.015;
  const march = -f * 0.8;
  // হুক: টাইল শুরুতে পর্দার মাঝখানে বড়, কথা এগোলে নিচে নামে
  const move = ease(f, T.you + 6, T.chip1 + 18, 0, 1, theme.ease.inOut);

  return (
    <SceneShell variant={0}>
      {/* হেডলাইন */}
      <AbsoluteFill style={{alignItems: 'center', justifyContent: 'flex-start', paddingTop: 104}}>
        <Words toks={['তোমার', 'কি']} at={T.you} per={5} size={72} color={theme.colors.textDim} />
        <Words
          toks={[
            {t: 'professional', hl: true},
            {t: 'logo', hl: true},
          ]}
          at={T.head}
          per={5}
          size={128}
          color={theme.colors.primary}
          cfg="snappy"
        />
        <div
          style={{
            marginTop: 6,
            fontFamily: theme.fonts.display,
            fontSize: 150,
            fontWeight: 700,
            lineHeight: 1.3,
            letterSpacing: 0,
            color: theme.colors.text,
            opacity: Math.min(1, askP),
            transform: `translateY(${lerp(askP, 50, 0)}px) scale(${lerp(askP, 0.8, 1)})`,
          }}
        >
          দরকার<span style={{color: theme.colors.accent}}>?</span>
        </div>
      </AbsoluteFill>

      {/* খালি লোগো-টাইল */}
      <div
        style={{
          position: 'absolute',
          left: (1440 - TILE) / 2,
          top: lerp(move, 380, 640),
          width: TILE,
          height: TILE,
          opacity: Math.min(1, tileP),
          transform: `scale(${lerp(tileP, 0.8, 1) * lerp(move, 1.25, 1) * breathe * (1 + pulse * 0.05)})`,
        }}
      >
        <svg width={TILE} height={TILE} viewBox={`0 0 ${TILE} ${TILE}`} fill="none">
          <rect
            x="6"
            y="6"
            width={TILE - 12}
            height={TILE - 12}
            rx="86"
            fill={theme.colors.wash}
            stroke={pulse > 0.05 ? theme.colors.primaryLight : theme.colors.lineStrong}
            strokeWidth="5"
            strokeDasharray="18 16"
            strokeDashoffset={march}
            strokeLinecap="round"
          />
        </svg>
        <div
          style={{
            position: 'absolute',
            inset: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontFamily: theme.fonts.display,
            fontSize: 190,
            fontWeight: 700,
            color: theme.colors.textDim,
            opacity: Math.min(1, q),
            transform: `scale(${lerp(q, 0.4, 1)})`,
          }}
        >
          ?
        </div>
      </div>

      {/* চিপ: YouTube channel */}
      <div style={{position: 'absolute', left: 54, top: 770}}>
        <Rise at={T.chip1} dx={-90} dy={0} cfg="snappy">
          <Pill size={40} bg={theme.colors.surface} border={theme.colors.lineStrong}>
            <IconChannel size={46} color={theme.colors.primaryLight} />
            YouTube channel
          </Pill>
        </Rise>
      </div>
      {/* চিপ: নিজের ব্যবসা */}
      <div style={{position: 'absolute', right: 54, top: 770}}>
        <Rise at={T.chip2} dx={90} dy={0} cfg="snappy">
          <Pill size={40} bg={theme.colors.surface} border={theme.colors.lineStrong}>
            <IconStore size={46} color={theme.colors.accent} />
            নিজের ব্যবসা
          </Pill>
        </Rise>
      </div>
    </SceneShell>
  );
};
