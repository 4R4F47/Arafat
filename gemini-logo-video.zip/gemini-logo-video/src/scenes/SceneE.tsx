// সিন E — রেজাল্ট (cue 5) · Gradient Fluid → Bento Grid, তারপর "পছন্দের design" বাছাই
import React from 'react';
import {AbsoluteFill} from 'remotion';
import {theme} from '../theme';
import {SceneShell} from '../components/layers';
import {ease, lerp, Rise, useAbs, useSpringAt, Words} from '../components/motion';
import {IconCheck, IconClock, Mark, MarkKind, Pill, surfaceCard} from '../components/art';
import type {SfxEvent} from '../components/Sfx';
import {LEAD, sceneRange, when} from '../timing';

export const rangeE = sceneRange(5, 5);

const T = {
  gen: rangeE.from - LEAD + 3,
  secs: when(5, 'কয়েক সেকেন্ডের'),
  cards: when(5, 'তৈরি'),
  title: when(5, 'logo design'),
  pick: when(5, 'পছন্দের'),
};

export const sfxE: SfxEvent[] = [
  {at: T.gen, name: 'swish'},
  {at: T.secs + 1, name: 'pop', rate: 0.95},
  {at: T.cards + 1, name: 'pop', rate: 1.05},
  {at: T.cards + 14, name: 'chime', vol: 0.8},
  {at: T.pick + 2, name: 'click'},
];

const GRID: {kind: MarkKind; id: string}[] = [
  {kind: 'cube', id: 'e0'},
  {kind: 'ring', id: 'e1'},
  {kind: 'orbit', id: 'e2'},
  {kind: 'bolt', id: 'e3'},
];
const SELECTED = 0;
const CW = 440;
const CH = 330;
const GAP = 32;
const GX = (1440 - (CW * 2 + GAP)) / 2;
const GY = 262;

export const SceneE: React.FC = () => {
  const f = useAbs();
  const blobIn = useSpringAt(T.gen, 'smooth');
  const blobOut = ease(f, T.cards - 2, T.cards + 16, 0, 1, theme.ease.in);
  const selP = ease(f, T.pick, T.pick + 16, 0, 1, theme.ease.out);
  const okP = useSpringAt(T.pick + 6, 'bouncy');

  return (
    <SceneShell variant={4}>
      {/* গ্রেডিয়েন্ট ফ্লুইড — "তৈরি হচ্ছে" */}
      <AbsoluteFill style={{opacity: Math.min(1, blobIn) * (1 - blobOut), transform: `scale(${lerp(blobOut, 1, 0.7)})`}}>
        <div style={{position: 'absolute', left: 520 + Math.sin(f / 14) * 40, top: 330 + Math.cos(f / 17) * 30, width: 420, height: 420, borderRadius: '46% 54% 58% 42% / 50% 42% 58% 50%', background: `radial-gradient(circle at 30% 30%, ${theme.colors.primaryLight}, ${theme.colors.primary} 55%, transparent 72%)`, filter: 'blur(30px)', opacity: 0.95, transform: `rotate(${f * 1.4}deg)`}} />
        <div style={{position: 'absolute', left: 640 + Math.cos(f / 12) * 50, top: 440 + Math.sin(f / 15) * 40, width: 340, height: 340, borderRadius: '54% 46% 42% 58% / 44% 58% 42% 56%', background: `radial-gradient(circle at 60% 40%, ${theme.colors.accent}, transparent 68%)`, filter: 'blur(34px)', opacity: 0.85, transform: `rotate(${-f * 1.1}deg)`}} />
        <div style={{position: 'absolute', left: 0, right: 0, top: 800, display: 'flex', justifyContent: 'center'}}>
          <Rise at={T.secs} dy={34} cfg="snappy">
            <Pill size={56} bg={theme.colors.surface} border={theme.colors.lineStrong}>
              <IconClock size={58} color={theme.colors.accent} />
              কয়েক সেকেন্ডের মধ্যে
            </Pill>
          </Rise>
        </div>
      </AbsoluteFill>

      {/* শিরোনাম */}
      <AbsoluteFill style={{alignItems: 'center', justifyContent: 'flex-start', paddingTop: 70}}>
        <Words toks={[{t: 'logo', hl: true}, {t: 'design', hl: true}]} at={T.title} per={5} size={112} color={theme.colors.text} />
      </AbsoluteFill>

      {/* বেন্টো গ্রিড */}
      {GRID.map((g, i) => {
        const col = i % 2;
        const row = Math.floor(i / 2);
        const sel = i === SELECTED;
        const scale = sel ? lerp(selP, 1, 1.05) : lerp(selP, 1, 0.94);
        const fade = sel ? 1 : lerp(selP, 1, 0.32);
        return (
          <div key={i} style={{position: 'absolute', left: GX + col * (CW + GAP), top: GY + row * (CH + GAP)}}>
            <Rise at={T.cards + i * 5} dy={60} from={0.86} cfg="snappy">
              <div style={{opacity: fade, transform: `scale(${scale})`}}>
                <div
                  style={{
                    ...surfaceCard({width: CW, height: CH, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', borderRadius: 44}),
                    border: `${sel && selP > 0.05 ? 3 : 1}px solid ${sel && selP > 0.05 ? theme.colors.primary : theme.colors.line}`,
                    boxShadow: sel ? `${theme.shadow.card}, 0 0 ${60 * selP}px ${theme.colors.glow}` : theme.shadow.card,
                  }}
                >
                  <Mark kind={g.kind} size={210} id={g.id} />
                  {sel && (
                    <div
                      style={{
                        position: 'absolute',
                        right: 24,
                        top: 22,
                        width: 78,
                        height: 78,
                        borderRadius: '50%',
                        background: theme.colors.accent,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        opacity: Math.min(1, okP),
                        transform: `scale(${lerp(okP, 0.3, 1)})`,
                      }}
                    >
                      <IconCheck size={48} color={theme.colors.onAccent} />
                    </div>
                  )}
                </div>
              </div>
            </Rise>
          </div>
        );
      })}
    </SceneShell>
  );
};
