// সিন D — লোগোর ধরন + prompt (cue 4) · 3D Carousel → Kinetic Statement + Prompt Card
import React from 'react';
import {AbsoluteFill} from 'remotion';
import {theme} from '../theme';
import {SceneShell} from '../components/layers';
import {clamp01, ease, lerp, Rise, useAbs, useSpringAt, Words} from '../components/motion';
import {IconSend, Mark, MarkKind, Pill, surfaceCard} from '../components/art';
import type {SfxEvent} from '../components/Sfx';
import {cueEnd, LEAD, sceneRange, when} from '../timing';

export const rangeD = sceneRange(4, 4);

const ITEMS: {label: string; kind: MarkKind}[] = [
  {label: '3D logo', kind: 'cube'},
  {label: 'minimal logo', kind: 'ring'},
  {label: 'gaming logo', kind: 'bolt'},
];

// ক্যারোসেলের আইটেমগুলো cue-র সময়ে সমান ব্যবধানে (নামগুলো একই cue-তে বলা হয়)
const T0 = rangeD.from - LEAD + 4;
const T_PROMPT_TXT = when(4, 'তারপর');
const STEP = (T_PROMPT_TXT - T0) / ITEMS.length;
const SWITCH = [T0 + STEP - 6, T0 + STEP * 2 - 6];
const CAR_OUT = T_PROMPT_TXT - 6;
const T_AI = T_PROMPT_TXT;
const T_GOOD = when(4, 'ভালো');
const T_PROMPT = when(4, 'prompt');
const T_SEND = cueEnd(4) - 12;

export const sfxD: SfxEvent[] = [
  {at: T0, name: 'pop'},
  {at: SWITCH[0] + 2, name: 'swish', vol: 0.8},
  {at: SWITCH[1] + 2, name: 'swish', vol: 0.8, rate: 1.1},
  {at: T_AI + 1, name: 'swish'},
  {at: T_PROMPT + 1, name: 'pop', rate: 1.05},
  {at: T_SEND, name: 'click'},
];

const R = 860;
const DEG = 42; // কার্ডগুলো ৪২° ব্যবধানে ফ্যানের মতো সাজানো
const CARD_W = 460;
const CARD_H = 520;

const Counter: React.FC<{idx: number}> = ({idx}) => {
  return (
    <div style={{display: 'flex', alignItems: 'center', gap: 14, fontFamily: theme.fonts.display, fontWeight: 700, letterSpacing: 0, lineHeight: 1.2}}>
      <div style={{position: 'relative', width: 78, height: 70, overflow: 'hidden', fontSize: 62, color: theme.colors.text}}>
        {ITEMS.map((_, i) => {
          const d = i - idx;
          return (
            <div
              key={i}
              style={{
                position: 'absolute',
                left: 0,
                top: 0,
                width: '100%',
                textAlign: 'center',
                transform: `translateY(${d * 70}px)`,
                opacity: clamp01(1 - Math.abs(d)),
              }}
            >
              {`0${i + 1}`}
            </div>
          );
        })}
      </div>
      <span style={{fontSize: 40, color: theme.colors.textFaint}}>/ 0{ITEMS.length}</span>
    </div>
  );
};

export const SceneD: React.FC = () => {
  const f = useAbs();
  const s1 = useSpringAt(SWITCH[0], 'smooth');
  const s2 = useSpringAt(SWITCH[1], 'smooth');
  const idx = s1 + s2;
  const enter = useSpringAt(T0 - 4, 'smooth');
  const carQ = ease(f, CAR_OUT, CAR_OUT + 12, 0, 1, theme.ease.in);
  const send = ease(f, T_SEND - 2, T_SEND + 4, 0, 1) * (1 - ease(f, T_SEND + 4, T_SEND + 14, 0, 1));
  const ring = ease(f, T_SEND, T_SEND + 14, 0, 1);
  const lineP = (i: number) => ease(f, T_PROMPT + 4 + i * 6, T_PROMPT + 22 + i * 6, 0, 1, theme.ease.out);

  return (
    <SceneShell variant={3}>
      {/* --- ক্যারোসেল --- */}
      <AbsoluteFill style={{opacity: (1 - carQ) * Math.min(1, enter), transform: `scale(${1 - carQ * 0.14})`}}>
        <div style={{position: 'absolute', left: 0, right: 0, top: 70, display: 'flex', justifyContent: 'center'}}>
          <Counter idx={idx} />
        </div>
        <div style={{position: 'absolute', left: 0, top: 170, width: 1440, height: CARD_H + 40, perspective: 1900}}>
          <div
            style={{
              position: 'absolute',
              left: (1440 - CARD_W) / 2,
              top: 20,
              width: CARD_W,
              height: CARD_H,
              transformStyle: 'preserve-3d',
              transform: `translateZ(${-R}px) rotateY(${-idx * DEG}deg)`,
            }}
          >
            {ITEMS.map((it, i) => {
              const ang = (i - idx) * DEG;
              const facing = Math.cos((ang * Math.PI) / 180);
              return (
                <div
                  key={i}
                  style={{
                    position: 'absolute',
                    inset: 0,
                    transform: `rotateY(${i * DEG}deg) translateZ(${R}px)`,
                    backfaceVisibility: 'hidden',
                    opacity: lerp(clamp01(facing), 0.28, 1),
                  }}
                >
                  <div style={{...surfaceCard({width: CARD_W, height: CARD_H, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 56})}}>
                    <Mark kind={it.kind} size={290} id={`car${i}`} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        {/* সক্রিয় আইটেমের নাম */}
        <div style={{position: 'absolute', left: 0, right: 0, top: 780, height: 150}}>
          {ITEMS.map((it, i) => {
            const d = i - idx;
            return (
              <div
                key={i}
                style={{
                  position: 'absolute',
                  left: 0,
                  right: 0,
                  top: 0,
                  textAlign: 'center',
                  fontFamily: theme.fonts.display,
                  fontSize: 104,
                  fontWeight: 700,
                  lineHeight: 1.3,
                  letterSpacing: 0,
                  color: theme.colors.primary,
                  opacity: clamp01(1 - Math.abs(d) * 1.8),
                  transform: `translateY(${d * 60}px)`,
                }}
              >
                {it.label}
              </div>
            );
          })}
        </div>
      </AbsoluteFill>

      {/* --- prompt --- */}
      <AbsoluteFill style={{alignItems: 'center', justifyContent: 'flex-start', paddingTop: 100}}>
        <Words toks={['AIকে', 'একটা']} at={T_AI} per={5} size={78} color={theme.colors.textDim} />
        <Words toks={[{t: 'ভালো', hl: true}, {t: 'prompt', hl: true}]} at={T_GOOD} per={5} size={146} color={theme.colors.primary} />
      </AbsoluteFill>
      <div style={{position: 'absolute', left: 190, top: 560}}>
        <Rise at={T_AI + 4} dy={70} from={0.94} cfg="smooth" breathe={0.004}>
          <div style={{...surfaceCard({width: 1060, height: 380, position: 'relative', borderRadius: 48})}}>
            <div style={{position: 'absolute', left: 44, top: 36}}>
              <Pill size={34}>prompt</Pill>
            </div>
            <div style={{position: 'absolute', left: 52, right: 52, top: 130, display: 'flex', flexDirection: 'column', gap: 26}}>
              {[0.92, 0.8, 0.88, 0.46].map((w, i) => (
                <div key={i} style={{height: 24, width: `${w * 100}%`, borderRadius: 12, background: theme.colors.washHi, overflow: 'hidden'}}>
                  <div style={{width: '100%', height: '100%', borderRadius: 12, background: theme.colors.lineStrong, transform: `scaleX(${lineP(i)})`, transformOrigin: '0% 50%'}} />
                </div>
              ))}
            </div>
            <div
              style={{
                position: 'absolute',
                right: 36,
                bottom: 32,
                width: 92,
                height: 92,
                borderRadius: '50%',
                background: theme.colors.white,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                transform: `scale(${1 - send * 0.14})`,
                boxShadow: `0 0 0 ${ring * 26}px ${theme.colors.primarySoft}`,
              }}
            >
              <IconSend size={52} color={theme.colors.bg} />
            </div>
          </div>
        </Rise>
      </div>
    </SceneShell>
  );
};
