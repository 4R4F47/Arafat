import {loadFont} from '@remotion/google-fonts/HindSiliguri';

// Hind Siliguri: বাংলা যুক্তাক্ষর ঠিকভাবে আসে, সর্বোচ্চ ওজন 700।
// loadFont নিজেই ফন্ট লোড না হওয়া পর্যন্ত ফ্রেম ক্যাপচার আটকে রাখে।
const {fontFamily} = loadFont('normal', {
  weights: ['500', '600', '700'],
  subsets: ['bengali', 'latin', 'latin-ext'],
});

export const FONT_STACK = `${fontFamily}, 'Noto Sans Bengali', 'Nirmala UI', 'Segoe UI', sans-serif`;
