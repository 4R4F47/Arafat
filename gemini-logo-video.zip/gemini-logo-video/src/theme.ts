// theme.ts — সব রং, ইজিং, spring, ফন্ট এখানে। কম্পোনেন্টে সরাসরি রঙের কোড নয়।
// স্কিম: Gemini Spectrum Dark
import {Easing} from 'remotion';
import {FONT_STACK} from './fonts';

export const theme = {
  colors: {
    bg: '#111318',
    bgAlt: '#1A1D25',
    surface: '#1E222B',
    surfaceHi: '#272C38',
    primary: '#4C8DF6', // হিরো — প্রতি ফ্রেমে সবচেয়ে বেশি একটি জোরালো এলিমেন্ট
    primaryLight: '#8DB8FB',
    primaryDark: '#2B63C4',
    accent: '#F9AB00',
    text: '#FFFFFF',
    textDim: '#9AA3B5',
    textFaint: '#6B7385',
    onAccent: '#111318',
    white: '#FFFFFF',
    black: '#000000',
    line: 'rgba(255,255,255,0.10)',
    lineStrong: 'rgba(255,255,255,0.20)',
    wash: 'rgba(255,255,255,0.06)',
    washHi: 'rgba(255,255,255,0.12)',
    glow: 'rgba(76,141,246,0.45)',
    primarySoft: 'rgba(76,141,246,0.20)',
    accentSoft: 'rgba(249,171,0,0.18)',
  },
  fx: {
    vignette: 'rgba(0,0,0,0.5)',
    gradeTop: 'rgba(0,0,0,0.18)',
    gradeBottom: 'rgba(0,0,0,0.28)',
  },
  fonts: {
    display: FONT_STACK,
    body: FONT_STACK,
  },
  radius: {card: 40, tile: 84, pill: 999},
  shadow: {
    card: '0 40px 80px -28px rgba(0,0,0,0.7), 0 1px 0 rgba(255,255,255,0.06) inset',
    float: '0 28px 60px -20px rgba(0,0,0,0.75)',
  },
  // ইজিং — linear নিষিদ্ধ
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6},
    smooth: {damping: 20, stiffness: 90, mass: 1},
    bouncy: {damping: 11, stiffness: 170, mass: 0.7},
  },
} as const;

export type SpringName = keyof typeof theme.spring;
