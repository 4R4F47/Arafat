// স্বয়ংক্রিয়ভাবে তৈরি — scripts/gen-cues.mjs (public/voiceover.srt থেকে)
export type Cue = {n: number; startMs: number; endMs: number; text: string};

export const cues: Cue[] = [
  {
    "n": 1,
    "startMs": 100,
    "endMs": 5440,
    "text": "আচ্ছা, তোমার কি YouTube channel বা নিজের ব্যবসার জন্য একটা professional logo দরকার?"
  },
  {
    "n": 2,
    "startMs": 5440,
    "endMs": 11600,
    "text": "কিন্তু designerকে টাকা দিতে চাও না? তাহলে এই trickটা তোমার জন্য। প্রথমে Google"
  },
  {
    "n": 3,
    "startMs": 11600,
    "endMs": 17600,
    "text": "গিয়ে Gemini AI search করো। এরপর তোমার brand নাম লিখে বলো তুমি কেমন logo চাও।"
  },
  {
    "n": 4,
    "startMs": 17600,
    "endMs": 24580,
    "text": "যেমন 3D logo, minimal logo অথবা gaming logo। তারপর AIকে একটা ভালো prompt"
  },
  {
    "n": 5,
    "startMs": 24580,
    "endMs": 29780,
    "text": "দাও। কয়েক সেকেন্ডের মধ্যেই তৈরি হয়ে যাবে তোমার logo design। পছন্দের designটি"
  },
  {
    "n": 6,
    "startMs": 29780,
    "endMs": 35420,
    "text": "download করে ব্যবহার করতে পারবে। তবে মনে রেখো, কিছু feature জন্য login বা usage"
  },
  {
    "n": 7,
    "startMs": 35420,
    "endMs": 36280,
    "text": "limit থাকতে পারে।"
  }
];
