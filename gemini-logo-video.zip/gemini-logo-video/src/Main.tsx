import React from 'react';
import {AbsoluteFill, Sequence, useCurrentFrame} from 'remotion';
import {theme} from './theme';
import {VIDEO} from './config';
import {LEAD, Range, TRAIL} from './timing';
import {Grade, Grain, Vignette} from './components/layers';
import {SceneCtx, ease} from './components/motion';
import {PreviewAudio} from './components/PreviewAudio';
import {SfxEvent, SfxLayer} from './components/Sfx';
import {rangeA, SceneA, sfxA} from './scenes/SceneA';
import {rangeB, SceneB, sfxB} from './scenes/SceneB';
import {rangeC, SceneC, sfxC} from './scenes/SceneC';
import {rangeD, SceneD, sfxD} from './scenes/SceneD';
import {rangeE, SceneE, sfxE} from './scenes/SceneE';
import {rangeF, SceneF, sfxF} from './scenes/SceneF';

const SCENES: {range: Range; Comp: React.FC}[] = [
  {range: rangeA, Comp: SceneA},
  {range: rangeB, Comp: SceneB},
  {range: rangeC, Comp: SceneC},
  {range: rangeD, Comp: SceneD},
  {range: rangeE, Comp: SceneE},
  {range: rangeF, Comp: SceneF},
];

// সিন ট্রানজিশনে একটি করে নরম whoosh (সীমানার ৬ ফ্রেম আগে)
const BOUNDARIES = SCENES.slice(0, -1).map((s) => s.range.to);
const SFX: SfxEvent[] = [
  ...sfxA,
  ...sfxB,
  ...sfxC,
  ...sfxD,
  ...sfxE,
  ...sfxF,
  ...BOUNDARIES.map((b, i): SfxEvent => ({at: b - 6, name: 'whoosh', rate: i % 2 === 0 ? 1 : 1.06})),
];

const Scn: React.FC<{range: Range; last: boolean; children: React.ReactNode}> = ({range, last, children}) => {
  const lead = range.from === 0 ? 0 : LEAD;
  const trail = last ? 0 : TRAIL;
  const start = range.from - lead;
  const dur = range.to - range.from + lead + trail;
  return (
    <Sequence from={start} durationInFrames={dur}>
      <SceneCtx.Provider value={{start, dur}}>{children}</SceneCtx.Provider>
    </Sequence>
  );
};

// সিন ট্রানজিশন: হিরো-রঙের মাস্ক-উইপ, কাট লুকানো থাকে নিচে
const Wipe: React.FC = () => {
  const f = useCurrentFrame();
  const W = VIDEO.width;
  const p = ease(f, 0, 17, 0, 1, theme.ease.inOut);
  const p2 = ease(f, 2, 19, 0, 1, theme.ease.inOut);
  const x = -W * 1.9 + W * 3.8 * p;
  const x2 = -W * 1.9 + W * 3.8 * p2;
  const panel = (tx: number, bg: string): React.CSSProperties => ({
    position: 'absolute',
    top: -100,
    bottom: -100,
    left: -W * 0.3,
    width: W * 1.6,
    transform: `translateX(${tx}px) skewX(-12deg)`,
    background: bg,
  });
  return (
    <AbsoluteFill style={{pointerEvents: 'none', overflow: 'hidden'}}>
      <div style={panel(x2, theme.colors.bgAlt)} />
      <div style={panel(x, `linear-gradient(100deg, ${theme.colors.primaryDark}, ${theme.colors.primary} 55%, ${theme.colors.primaryLight})`)} />
    </AbsoluteFill>
  );
};

export const Main: React.FC = () => (
  <AbsoluteFill style={{background: theme.colors.bg, fontFamily: theme.fonts.body}}>
    {SCENES.map(({range, Comp}, i) => (
      <Scn key={i} range={range} last={i === SCENES.length - 1}>
        <Comp />
      </Scn>
    ))}
    {BOUNDARIES.map((b, i) => (
      <Sequence key={i} from={b - 9} durationInFrames={20}>
        <Wipe />
      </Sequence>
    ))}
    <Grade />
    <Grain />
    <Vignette />
    <SfxLayer events={SFX} />
    <PreviewAudio />
  </AbsoluteFill>
);
