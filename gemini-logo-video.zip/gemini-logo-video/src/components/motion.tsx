import React, {createContext, useContext} from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme, SpringName} from '../theme';

// ---------- সিন-ঘড়ি: সিনের ভেতরেও পুরো ভিডিওর (absolute) ফ্রেম নম্বর ----------
type Ctx = {start: number; dur: number};
export const SceneCtx = createContext<Ctx>({start: 0, dur: 0});

/** পুরো ভিডিওর ফ্রেম নম্বর (Sequence-এর ভেতরেও) */
export const useAbs = (): number => {
  const f = useCurrentFrame();
  return f + useContext(SceneCtx).start;
};
/** এই সিনের শেষ ফ্রেম (absolute) */
export const useSceneEnd = (): number => {
  const c = useContext(SceneCtx);
  return c.start + c.dur;
};

// ---------- ছোট গণিত ----------
export const clamp01 = (x: number) => Math.min(1, Math.max(0, x));

/** ইজড interpolate — সবসময় clamp, linear নয় */
export const ease = (
  f: number,
  a: number,
  b: number,
  from: number,
  to: number,
  easing: (t: number) => number = theme.ease.out,
) => interpolate(f, [a, b], [from, to], {easing, extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

export const lerp = (p: number, from: number, to: number) => from + (to - from) * p;

export const useSpringAt = (at: number, cfg: SpringName = 'smooth') => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  return spring({frame: f - at, fps, config: theme.spring[cfg]});
};

/** idle breathing: স্ক্রিনে ২ সেকেন্ডের বেশি থাকা এলিমেন্টে ছোট sin-মোশন */
export const useBreathe = (amp = 0.015, period = 22, phase = 0) => {
  const f = useAbs();
  return {
    s: 1 + Math.sin(f / period + phase) * amp,
    y: Math.sin(f / (period * 1.4) + phase) * 6,
  };
};

// ---------- Rise: ২-৩ প্রপার্টি একসাথে (opacity + translate + scale) ----------
export const Rise: React.FC<{
  at: number;
  dx?: number;
  dy?: number;
  from?: number;
  cfg?: SpringName;
  /** এই absolute ফ্রেমে দ্রুত এক্সিট শুরু (১০ ফ্রেম) */
  out?: number;
  breathe?: number;
  origin?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({at, dx = 0, dy = 44, from = 0.94, cfg = 'smooth', out, breathe = 0, origin = '50% 50%', style, children}) => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const p = spring({frame: f - at, fps, config: theme.spring[cfg]});
  const q = out === undefined ? 0 : ease(f, out, out + 10, 0, 1, theme.ease.in);
  const b = breathe ? 1 + Math.sin(f / 22 + at) * breathe : 1;
  const sc = lerp(p, from, 1) * (1 - q * 0.06) * b;
  return (
    <div
      style={{
        opacity: clamp01(p) * (1 - q),
        transform: `translate(${lerp(p, dx, 0)}px, ${lerp(p, dy, 0) - q * 26}px) scale(${sc})`,
        transformOrigin: origin,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

// ---------- Words: শব্দ-বাই-শব্দ স্ট্যাগার্ড (শুধু স্পেসে ভাঙে, অক্ষরে কখনো নয়) ----------
export type Tok = string | {t: string; color?: string; hl?: boolean; hlColor?: string};

export const Words: React.FC<{
  toks: Tok[];
  at: number;
  per?: number;
  size: number;
  color?: string;
  weight?: number;
  align?: 'center' | 'flex-start' | 'flex-end';
  out?: number;
  lh?: number;
  cfg?: SpringName;
  style?: React.CSSProperties;
}> = ({toks, at, per = 4, size, color = theme.colors.text, weight = 700, align = 'center', out, lh = 1.3, cfg = 'snappy', style}) => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  return (
    <div
      style={{
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: align,
        columnGap: Math.round(size * 0.26),
        rowGap: 0,
        fontFamily: theme.fonts.display,
        fontSize: size,
        fontWeight: weight,
        lineHeight: lh,
        letterSpacing: 0,
        color,
        ...style,
      }}
    >
      {toks.map((tok, i) => {
        const t = typeof tok === 'string' ? {t: tok} : tok;
        const p = spring({frame: f - at - i * per, fps, config: theme.spring[cfg]});
        const q = out === undefined ? 0 : ease(f, out + i, out + 10 + i, 0, 1, theme.ease.in);
        const sweep = t.hl ? ease(f, at + i * per + 8, at + i * per + 26, 0, 1, theme.ease.out) : 0;
        return (
          <span
            key={i}
            style={{
              position: 'relative',
              display: 'inline-block',
              whiteSpace: 'nowrap',
              color: t.color ?? color,
              opacity: clamp01(p) * (1 - q),
              transform: `translateY(${lerp(p, size * 0.42, 0) - q * size * 0.3}px) scale(${lerp(p, 0.94, 1)})`,
            }}
          >
            {t.hl && (
              <span
                style={{
                  position: 'absolute',
                  left: -size * 0.08,
                  right: -size * 0.08,
                  top: '30%',
                  bottom: '8%',
                  borderRadius: size * 0.2,
                  background: t.hlColor ?? theme.colors.primarySoft,
                  transform: `scaleX(${sweep})`,
                  transformOrigin: '0% 50%',
                  zIndex: -1,
                }}
              />
            )}
            {t.t}
          </span>
        );
      })}
    </div>
  );
};

/** বাম→ডান মাস্ক-সুইপ (বাংলা টাইপরাইটারের বিকল্প; অক্ষর ভাঙে না) */
export const MaskSweep: React.FC<{
  at: number;
  dur?: number;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({at, dur = 18, style, children}) => {
  const f = useAbs();
  const p = ease(f, at, at + dur, 0, 100, theme.ease.inOut);
  return (
    <div style={{clipPath: `inset(-40px ${100 - p}% -40px -40px)`, ...style}}>{children}</div>
  );
};
