import React from 'react';
import {theme} from '../theme';

// ---------- আইকন (24-গ্রিড, stroke-ভিত্তিক, থিমের রঙে) ----------
type IconProps = {size?: number; color?: string; sw?: number; style?: React.CSSProperties};

const Svg: React.FC<{size: number; style?: React.CSSProperties; children?: React.ReactNode}> = ({size, style, children}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={style}>
    {children}
  </svg>
);

const mk = (draw: (c: string, sw: number) => React.ReactNode, defSw = 1.8): React.FC<IconProps> =>
  ({size = 48, color = theme.colors.text, sw = defSw, style}) => (
    <Svg size={size} style={style}>
      <g stroke={color} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">
        {draw(color, sw)}
      </g>
    </Svg>
  );

export const IconSearch = mk(() => (
  <>
    <circle cx="11" cy="11" r="6.5" />
    <path d="M16 16l4.5 4.5" />
  </>
));
export const IconChannel = mk(() => (
  <>
    <rect x="3" y="4.5" width="18" height="12.5" rx="2.5" />
    <path d="M10 8.7l4.6 2.55L10 13.8z" />
    <path d="M8 20.5h8M12 17v3.5" />
  </>
));
export const IconStore = mk(() => (
  <>
    <path d="M4 9.5l1.4-4.5h13.2L20 9.5" />
    <path d="M4 9.5a2.7 2.7 0 005.33 0 2.7 2.7 0 005.34 0 2.7 2.7 0 005.33 0" />
    <path d="M5.5 12.5v7h13v-7" />
    <path d="M10 19.5v-4h4v4" />
  </>
));
export const IconPerson = mk(() => (
  <>
    <circle cx="12" cy="8" r="4" />
    <path d="M4.5 20c.8-4 3.7-6 7.5-6s6.7 2 7.5 6" />
  </>
));
export const IconCoin = mk(() => (
  <>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 7v10M14.6 9.5c-.6-.8-1.5-1.2-2.6-1.2-1.5 0-2.6.8-2.6 1.9 0 2.7 5.4 1.3 5.4 4 0 1.2-1.1 1.9-2.8 1.9-1.2 0-2.2-.4-2.8-1.3" />
  </>
));
export const IconBolt: React.FC<IconProps> = ({size = 48, color = theme.colors.text, style}) => (
  <Svg size={size} style={style}>
    <path d="M13 2.5L5 13.5h6l-1 8 8-11h-6z" fill={color} stroke={color} strokeWidth={1.2} strokeLinejoin="round" />
  </Svg>
);
export const IconCheck = mk(() => <path d="M5 12.5l4.5 4.5L19 7.5" />, 2.6);
export const IconLock = mk((c) => (
  <>
    <rect x="5" y="10.5" width="14" height="10" rx="2.5" />
    <path d="M8 10.5V8a4 4 0 018 0v2.5" />
    <circle cx="12" cy="15.5" r="1.2" fill={c} />
  </>
));
export const IconDownload = mk(() => <path d="M12 4v11M7.5 10.5L12 15l4.5-4.5M5 19.5h14" />, 2.2);
export const IconSend = mk(() => <path d="M12 19V5M6.5 10.5L12 5l5.5 5.5" />, 2.4);
export const IconClock = mk(() => (
  <>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 7.5V12l3 2" />
  </>
));
export const IconAlert = mk(() => (
  <>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 7.5v5.5M12 16.4v.1" />
  </>
), 2.2);

// ---------- জেনেরিক লোগো-মার্ক (ব্র্যান্ড লোগো নয়; AI-র "ডিজাইন রেজাল্ট"-এর নমুনা) ----------
type MarkProps = {size?: number; id: string};

/** 3D logo — আইসোমেট্রিক কিউব */
export const MarkCube: React.FC<MarkProps> = ({size = 220, id}) => (
  <svg width={size} height={size} viewBox="0 0 200 200" fill="none">
    <defs>
      <linearGradient id={`${id}-t`} x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor={theme.colors.primaryLight} />
        <stop offset="1" stopColor={theme.colors.primary} />
      </linearGradient>
      <linearGradient id={`${id}-l`} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={theme.colors.primary} />
        <stop offset="1" stopColor={theme.colors.primaryDark} />
      </linearGradient>
      <linearGradient id={`${id}-r`} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={theme.colors.primaryDark} />
        <stop offset="1" stopColor={theme.colors.bgAlt} />
      </linearGradient>
    </defs>
    <path d="M100 18L172 58L100 98L28 58Z" fill={`url(#${id}-t)`} />
    <path d="M28 58L100 98V182L28 142Z" fill={`url(#${id}-l)`} />
    <path d="M172 58L100 98V182L172 142Z" fill={`url(#${id}-r)`} />
    <path d="M100 98V182" stroke={theme.colors.accent} strokeWidth="4" strokeLinecap="round" />
  </svg>
);

/** minimal logo — রিং + বিন্দু */
export const MarkRing: React.FC<MarkProps> = ({size = 220}) => (
  <svg width={size} height={size} viewBox="0 0 200 200" fill="none">
    <circle cx="100" cy="100" r="62" stroke={theme.colors.text} strokeWidth="10" />
    <circle cx="100" cy="100" r="26" fill={theme.colors.text} opacity="0.14" />
    <circle cx="146" cy="54" r="15" fill={theme.colors.accent} />
  </svg>
);

/** দুই বৃত্তের ওভারল্যাপ */
export const MarkOrbit: React.FC<MarkProps> = ({size = 220}) => (
  <svg width={size} height={size} viewBox="0 0 200 200" fill="none">
    <circle cx="78" cy="100" r="54" fill={theme.colors.primary} opacity="0.92" />
    <circle cx="124" cy="100" r="54" fill={theme.colors.accent} opacity="0.88" style={{mixBlendMode: 'screen'}} />
  </svg>
);

/** gaming logo — হেক্সাগন + বোল্ট */
export const MarkBolt: React.FC<MarkProps> = ({size = 220}) => (
  <svg width={size} height={size} viewBox="0 0 200 200" fill="none">
    <path
      d="M100 20L170 60V140L100 180L30 140V60Z"
      stroke={theme.colors.text}
      strokeWidth="9"
      strokeLinejoin="round"
    />
    <path d="M108 52L72 106H98L90 150L130 92H104Z" fill={theme.colors.accent} stroke={theme.colors.accent} strokeWidth="3" strokeLinejoin="round" />
  </svg>
);

export type MarkKind = 'cube' | 'ring' | 'orbit' | 'bolt';
export const Mark: React.FC<{kind: MarkKind; size?: number; id: string}> = ({kind, size, id}) => {
  if (kind === 'cube') return <MarkCube size={size} id={id} />;
  if (kind === 'ring') return <MarkRing size={size} id={id} />;
  if (kind === 'orbit') return <MarkOrbit size={size} id={id} />;
  return <MarkBolt size={size} id={id} />;
};

// ---------- ছোট UI ফাউন্ডেশন ----------
export const surfaceCard = (extra?: React.CSSProperties): React.CSSProperties => ({
  background: `linear-gradient(160deg, ${theme.colors.surfaceHi}, ${theme.colors.surface})`,
  border: `1px solid ${theme.colors.line}`,
  borderRadius: theme.radius.card,
  boxShadow: theme.shadow.card,
  ...extra,
});

export const Pill: React.FC<{
  children?: React.ReactNode;
  size?: number;
  bg?: string;
  color?: string;
  border?: string;
  style?: React.CSSProperties;
}> = ({children, size = 38, bg = theme.colors.wash, color = theme.colors.text, border = theme.colors.line, style}) => (
  <div
    style={{
      display: 'inline-flex',
      alignItems: 'center',
      gap: Math.round(size * 0.3),
      padding: `${Math.round(size * 0.3)}px ${Math.round(size * 0.7)}px`,
      borderRadius: theme.radius.pill,
      background: bg,
      border: `1px solid ${border}`,
      color,
      fontFamily: theme.fonts.body,
      fontSize: size,
      fontWeight: 600,
      lineHeight: 1.3,
      letterSpacing: 0,
      whiteSpace: 'nowrap',
      ...style,
    }}
  >
    {children}
  </div>
);
