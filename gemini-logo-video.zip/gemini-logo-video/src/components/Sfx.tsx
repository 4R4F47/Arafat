import React from 'react';
import {Audio, Sequence, staticFile, useVideoConfig} from 'remotion';

// ছোট, নরম, আধুনিক UI-ধাঁচের ৬টি SFX (public/sfx/*.wav — scripts/make-sfx.mjs দিয়ে তৈরি)
export type SfxName = 'thud' | 'pop' | 'click' | 'swish' | 'whoosh' | 'chime';
export type SfxEvent = {at: number; name: SfxName; vol?: number; rate?: number};

// ফাইলের দৈর্ঘ্য (সেকেন্ড) — make-sfx.mjs-এর রিপোর্টের সাথে মেলে
const LEN: Record<SfxName, number> = {thud: 0.3, pop: 0.22, click: 0.1, swish: 0.4, whoosh: 0.65, chime: 0.55};
// সংযত ভলিউম (০.২–০.৩৫)
const BASE: Record<SfxName, number> = {thud: 0.3, pop: 0.28, click: 0.3, swish: 0.22, whoosh: 0.26, chime: 0.26};

export const SfxLayer: React.FC<{events: SfxEvent[]}> = ({events}) => {
  const {fps} = useVideoConfig();
  return (
    <>
      {events.map((e, i) => {
        const rate = e.rate ?? 1;
        return (
          <Sequence key={i} from={Math.max(0, Math.round(e.at))} durationInFrames={Math.ceil((LEN[e.name] / rate) * fps) + 4}>
            <Audio src={staticFile(`sfx/${e.name}.wav`)} volume={BASE[e.name] * (e.vol ?? 1)} playbackRate={rate} />
          </Sequence>
        );
      })}
    </>
  );
};
