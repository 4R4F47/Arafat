import React, {useEffect, useState} from 'react';
import {Audio, continueRender, delayRender, getRemotionEnvironment, staticFile} from 'remotion';
import {VOICEOVER} from '../config';

/**
 * public/voiceover.mp3 থাকলে বাজে, না থাকলে নীরবে বাদ।
 * Studio প্রিভিউতে VOICEOVER.preview, রেন্ডারে VOICEOVER.render (ডিফল্ট: বন্ধ)।
 */
export const PreviewAudio: React.FC = () => {
  const env = getRemotionEnvironment();
  const enabled = env.isRendering ? VOICEOVER.render : VOICEOVER.preview;
  const [found, setFound] = useState(false);
  const [handle] = useState(() => (enabled ? delayRender('voiceover probe') : null));

  useEffect(() => {
    if (!enabled || handle === null) return;
    let alive = true;
    fetch(staticFile('voiceover.mp3'), {method: 'HEAD'})
      .then((r) => {
        const type = r.headers.get('content-type') ?? '';
        if (alive && r.ok && (type.includes('audio') || type.includes('octet-stream'))) setFound(true);
      })
      .catch(() => undefined)
      .finally(() => continueRender(handle));
    return () => {
      alive = false;
    };
  }, [enabled, handle]);

  if (!enabled || !found) return null;
  return <Audio src={staticFile('voiceover.mp3')} />;
};
