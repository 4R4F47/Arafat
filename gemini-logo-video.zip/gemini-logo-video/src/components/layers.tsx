import React, {useContext} from 'react';
import {AbsoluteFill} from 'remotion';
import {theme} from '../theme';
import {ease, SceneCtx, useAbs, useSceneEnd} from './motion';
import {LEAD} from '../timing';

// ---------- ১. ব্যাকগ্রাউন্ড মেশ (কখনো ফ্ল্যাট রং নয়) ----------
const BLOBS = [
  {a: {x: -260, y: -380, s: 1250}, b: {x: 820, y: 640, s: 980}},
  {a: {x: 700, y: -420, s: 1150}, b: {x: -240, y: 600, s: 1000}},
  {a: {x: 120, y: -520, s: 1300}, b: {x: 760, y: 560, s: 900}},
  {a: {x: -300, y: 40, s: 1100}, b: {x: 780, y: -300, s: 1000}},
  {a: {x: 500, y: 200, s: 1200}, b: {x: -200, y: -380, s: 1000}},
  {a: {x: -200, y: -300, s: 1200}, b: {x: 700, y: 560, s: 1100}},
];

export const BgMesh: React.FC<{variant?: number}> = ({variant = 0}) => {
  const f = useAbs();
  const v = BLOBS[variant % BLOBS.length];
  const d1 = Math.sin(f / 55) * 50;
  const d2 = Math.cos(f / 70) * 40;
  return (
    <AbsoluteFill style={{background: theme.colors.bg}}>
      <div
        style={{
          position: 'absolute',
          left: v.a.x + d1,
          top: v.a.y + d2,
          width: v.a.s,
          height: v.a.s,
          borderRadius: '50%',
          filter: 'blur(50px)',
          background: `radial-gradient(circle, ${theme.colors.primary}38, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: 'absolute',
          left: v.b.x - d2,
          top: v.b.y - d1,
          width: v.b.s,
          height: v.b.s,
          borderRadius: '50%',
          filter: 'blur(70px)',
          background: `radial-gradient(circle, ${theme.colors.accent}22, transparent 65%)`,
        }}
      />
      {/* সূক্ষ্ম ডট-গ্রিড টেক্সচার */}
      <AbsoluteFill
        style={{
          backgroundImage: `radial-gradient(${theme.colors.wash} 1.6px, transparent 1.8px)`,
          backgroundSize: '54px 54px',
          backgroundPosition: `${(f * 0.25) % 54}px ${(f * 0.12) % 54}px`,
          opacity: 0.7,
        }}
      />
    </AbsoluteFill>
  );
};

// ---------- ৪. কালার গ্রেড (সব কনটেন্টের উপরে) ----------
export const Grade: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: 'none'}}>
    <AbsoluteFill style={{backgroundColor: theme.colors.primary, mixBlendMode: 'soft-light', opacity: 0.18}} />
    <AbsoluteFill
      style={{
        background: `linear-gradient(180deg, ${theme.fx.gradeTop}, transparent 28%, transparent 72%, ${theme.fx.gradeBottom})`,
      }}
    />
  </AbsoluteFill>
);

// ---------- ৫. গ্রেইন + ভিগনেট ----------
export const Grain: React.FC = () => {
  const f = useAbs();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: 'none',
        backgroundImage: noise,
        backgroundSize: '220px',
        backgroundPosition: `${(f * 7) % 220}px ${(f * 13) % 220}px`,
        opacity: 0.06,
        mixBlendMode: 'overlay',
      }}
    />
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: 'none',
      background: `radial-gradient(ellipse at center, transparent 58%, ${theme.fx.vignette} 100%)`,
    }}
  />
);

// ---------- সিন শেল: মেশ + কনটেন্ট + দ্রুত এক্সিট ----------
export const SceneShell: React.FC<{variant?: number; children?: React.ReactNode}> = ({variant = 0, children}) => {
  const f = useAbs();
  const end = useSceneEnd();
  const {start} = useContext(SceneCtx);
  const q = ease(f, end - 11, end - 1, 0, 1, theme.ease.in);
  // পরের সিনের ব্যাকগ্রাউন্ড ট্রানজিশনের (wipe) নিচে ঢোকে, আগের সিনের শেষ অংশ ঢেকে দেয় না
  const bgIn = start === 0 ? 1 : ease(f, start + LEAD - 1, start + LEAD + 7, 0, 1, theme.ease.inOut);
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{opacity: bgIn}}>
        <BgMesh variant={variant} />
      </AbsoluteFill>
      <AbsoluteFill style={{opacity: 1 - q, transform: `translateY(${-q * 28}px) scale(${1 + q * 0.02})`}}>
        {children}
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
