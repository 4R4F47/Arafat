// সব সময় SRT (src/cues.ts) থেকে হিসাব হয়। হাতে বসানো ফ্রেম নম্বর নেই।
import {cues} from './cues';
import {VIDEO} from './config';

const {fps} = VIDEO;

/** ভিজ্যুয়াল সংশ্লিষ্ট কথার এত ফ্রেম আগে ঢোকে (৪-৬ ফ্রেম) */
export const LEAD = 5;
/** সিন ট্রানজিশনের নিচে লুকানো ওভারল্যাপ */
export const TRAIL = 8;

const toFrame = (ms: number) => Math.round((ms / 1000) * fps);

export const TOTAL_FRAMES = Math.ceil((cues[cues.length - 1].endMs / 1000) * fps);

export const cueStart = (n: number) => toFrame(cues[n - 1].startMs);
export const cueEnd = (n: number) => toFrame(cues[n - 1].endMs);

/**
 * cue-র ভেতরের কোনো শব্দ/বাক্যাংশ কখন বলা হবে — অক্ষরের অনুপাতে cue-র সময়ে বসানো হয়
 * (SRT-তে শব্দ-স্তরের সময় নেই), তারপর LEAD ফ্রেম আগে টানা হয়।
 * বাক্যাংশ না মিললে বিল্ড-টাইমেই এরর দেয়, তাই বানান ভুল ধরা পড়ে।
 */
export const when = (n: number, phrase: string, lead: number = LEAD): number => {
  const c = cues[n - 1];
  const idx = c.text.indexOf(phrase);
  if (idx < 0) throw new Error(`cue ${n}-এ "${phrase}" পাওয়া যায়নি`);
  const ratio = idx / c.text.length;
  const start = (c.startMs / 1000) * fps;
  const end = (c.endMs / 1000) * fps;
  return Math.round(start + ratio * (end - start) - lead);
};

export type Range = {from: number; to: number};

/** সিনের সীমা = cue-র সীমা। প্রথম সিন 0 থেকে, শেষ সিন ভিডিওর শেষ পর্যন্ত। */
export const sceneRange = (firstCue: number, lastCue: number): Range => ({
  from: firstCue === 1 ? 0 : cueStart(firstCue),
  to: lastCue === cues.length ? TOTAL_FRAMES : cueEnd(lastCue),
});
