// প্রজেক্টের মূল সেটিংস। সাইজ/ফ্রেম রেট বদলাতে শুধু এখানে হাত দিলেই হয়।
export const VIDEO = {
  width: 1440, // 4:3
  height: 1080,
  fps: 30,
} as const;

// ভয়েসওভার (public/voiceover.mp3) — ফাইল না থাকলে নীরবে বাদ পড়ে।
// preview: Remotion Studio-তে বাজবে কি না
// render:  রেন্ডার করা MP4-তে মিশবে কি না (ডিফল্টে বন্ধ — শুধু SFX থাকবে)
export const VOICEOVER = {
  preview: true,
  render: false,
} as const;
