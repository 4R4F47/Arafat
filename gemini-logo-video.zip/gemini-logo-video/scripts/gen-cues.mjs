// public/voiceover.srt → src/cues.ts
// SRT বদলালে: node scripts/gen-cues.mjs
import {readFileSync, writeFileSync} from 'node:fs';

const raw = readFileSync(new URL('../public/voiceover.srt', import.meta.url), 'utf8').replace(/\r/g, '');
const toMs = (s) => {
  const m = s.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  return ((+m[1] * 60 + +m[2]) * 60 + +m[3]) * 1000 + +m[4];
};

const cues = raw
  .split(/\n\s*\n/)
  .map((b) => b.trim().split('\n'))
  .filter((l) => l.length >= 3 && l[1].includes('-->'))
  .map((l) => {
    const [a, b] = l[1].split('-->');
    return {n: +l[0], startMs: toMs(a), endMs: toMs(b), text: l.slice(2).join(' ').replace(/\s+/g, ' ').trim()};
  });

const out = `// স্বয়ংক্রিয়ভাবে তৈরি — scripts/gen-cues.mjs (public/voiceover.srt থেকে)
export type Cue = {n: number; startMs: number; endMs: number; text: string};

export const cues: Cue[] = ${JSON.stringify(cues, null, 2)};
`;
writeFileSync(new URL('../src/cues.ts', import.meta.url), out);
console.log(`${cues.length} cues, last end ${cues[cues.length - 1].endMs}ms`);
