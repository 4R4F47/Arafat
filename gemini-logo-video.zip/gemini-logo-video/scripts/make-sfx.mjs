// public/sfx/*.wav — কোডে সিন্থেসাইজ করা ৬টি ছোট, নরম UI সাউন্ড (কোনো ডাউনলোড নেই)
// চালাতে: node scripts/make-sfx.mjs
import {mkdirSync, writeFileSync} from 'node:fs';

const SR = 44100;
const OUT = new URL('../public/sfx/', import.meta.url);
mkdirSync(OUT, {recursive: true});

// নির্ধারিত (deterministic) র‍্যান্ডম
const rng = (seed) => () => {
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

// ---- biquad (RBJ) ----
const biquad = (type, fc, q = 0.707) => {
  const w = (2 * Math.PI * fc) / SR;
  const al = Math.sin(w) / (2 * q);
  const cs = Math.cos(w);
  let b0, b1, b2, a0, a1, a2;
  if (type === 'lp') {
    b0 = (1 - cs) / 2; b1 = 1 - cs; b2 = (1 - cs) / 2;
  } else if (type === 'hp') {
    b0 = (1 + cs) / 2; b1 = -(1 + cs); b2 = (1 + cs) / 2;
  } else {
    b0 = al; b1 = 0; b2 = -al; // bp (constant 0 dB peak)
  }
  a0 = 1 + al; a1 = -2 * cs; a2 = 1 - al;
  return {b0: b0 / a0, b1: b1 / a0, b2: b2 / a0, a1: a1 / a0, a2: a2 / a0};
};
const runBiquad = (x, c) => {
  const y = new Float64Array(x.length);
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  for (let i = 0; i < x.length; i++) {
    const v = c.b0 * x[i] + c.b1 * x1 + c.b2 * x2 - c.a1 * y1 - c.a2 * y2;
    y[i] = v; x2 = x1; x1 = x[i]; y2 = y1; y1 = v;
  }
  return y;
};
const lp = (x, fc, q) => runBiquad(x, biquad('lp', fc, q));
const hp = (x, fc, q) => runBiquad(x, biquad('hp', fc, q));

// সময়ে বদলানো center-ফ্রিকোয়েন্সির band-pass (whoosh/swish)
const sweepBP = (x, f0, f1, q) => {
  const y = new Float64Array(x.length);
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / x.length;
    const fc = f0 * Math.pow(f1 / f0, t);
    const c = biquad('bp', fc, q);
    const v = c.b0 * x[i] + c.b1 * x1 + c.b2 * x2 - c.a1 * y1 - c.a2 * y2;
    y[i] = v; x2 = x1; x1 = x[i]; y2 = y1; y1 = v;
  }
  return y;
};

// খুব ছোট রিভার্ব (তিনটি comb)
const tinyReverb = (x, mix = 0.12) => {
  const y = Float64Array.from(x);
  for (const [ms, g] of [[23, 0.32], [31, 0.26], [43, 0.2]]) {
    const d = Math.round((ms / 1000) * SR);
    for (let i = d; i < y.length; i++) y[i] += y[i - d] * g * mix * 3;
  }
  return y;
};

const make = (dur, fn) => {
  const n = Math.round(dur * SR);
  const x = new Float64Array(n);
  for (let i = 0; i < n; i++) x[i] = fn(i / SR, i);
  return x;
};
const env = (t, atk, dec) => (1 - Math.exp(-t / atk)) * Math.exp(-t / dec);

const sounds = {};

// pop — দ্রুত নিচে নামা pitch সহ sine
{
  let ph = 0;
  const x = make(0.22, (t) => {
    const f = 170 + 520 * Math.exp(-t / 0.03);
    ph += (2 * Math.PI * f) / SR;
    return (Math.sin(ph) + 0.12 * Math.sin(2 * ph)) * env(t, 0.002, 0.05);
  });
  sounds.pop = tinyReverb(lp(x, 4200));
}
// click — high-pass করা ছোট noise burst + হালকা টিক
{
  const r = rng(11);
  const x = make(0.1, (t) => (r() * 2 - 1) * env(t, 0.0006, 0.007) + 0.35 * Math.sin(2 * Math.PI * 2100 * t) * env(t, 0.0004, 0.004));
  sounds.click = tinyReverb(lp(hp(x, 2200), 9000), 0.08);
}
// swish — ছোট, হালকা noise sweep (শিরোনাম এন্ট্রি)
{
  const r = rng(23);
  const raw = make(0.4, (t) => (r() * 2 - 1) * Math.pow(Math.sin(Math.PI * Math.min(1, t / 0.4)), 2));
  sounds.swish = tinyReverb(lp(sweepBP(raw, 700, 2600, 1.1), 6500));
}
// whoosh — মসৃণ ট্রানজিশন swipe
{
  const r = rng(37);
  const n = 0.65;
  const raw = make(n, (t) => {
    const a = Math.min(1, t / 0.2);
    const d = Math.min(1, (n - t) / 0.42);
    return (r() * 2 - 1) * a * a * d * d;
  });
  sounds.whoosh = tinyReverb(lp(sweepBP(raw, 320, 1900, 0.9), 5500));
}
// chime — নরম ওভারটোনসহ ছোট pluck
{
  const x = make(0.55, (t) => {
    const e = env(t, 0.004, 0.13);
    return (Math.sin(2 * Math.PI * 784 * t) + 0.32 * Math.sin(2 * Math.PI * 1568.6 * t) * Math.exp(-t / 0.08) + 0.1 * Math.sin(2 * Math.PI * 2352 * t) * Math.exp(-t / 0.05)) * e;
  });
  sounds.chime = tinyReverb(lp(x, 6000), 0.14);
}
// thud — খুব হালকা সফট থাড
{
  let ph = 0;
  const x = make(0.3, (t) => {
    const f = 52 + 48 * Math.exp(-t / 0.05);
    ph += (2 * Math.PI * f) / SR;
    return Math.sin(ph) * env(t, 0.008, 0.075);
  });
  sounds.thud = lp(x, 320);
}

// ---- নর্মালাইজ: সব সাউন্ডের RMS মেলানো, peak ≤ 0.8, শুরু-শেষে ফেড ----
const TARGET_RMS = 0.1;
const PEAK_CAP = 0.8;
const rows = [];
for (const [name, x0] of Object.entries(sounds)) {
  const x = Float64Array.from(x0);
  const fi = Math.round(0.001 * SR);
  const fo = Math.round(0.02 * SR);
  for (let i = 0; i < fi; i++) x[i] *= i / fi;
  for (let i = 0; i < fo; i++) x[x.length - 1 - i] *= i / fo;
  let sum = 0;
  for (const v of x) sum += v * v;
  const rms = Math.sqrt(sum / x.length) || 1;
  let g = TARGET_RMS / rms;
  let peak = 0;
  for (const v of x) peak = Math.max(peak, Math.abs(v));
  if (peak * g > PEAK_CAP) g = PEAK_CAP / peak;

  const pcm = Buffer.alloc(x.length * 2);
  let clip = 0, outPeak = 0, outSum = 0;
  for (let i = 0; i < x.length; i++) {
    const v = Math.max(-1, Math.min(1, x[i] * g));
    const s = Math.round(v * 32767);
    if (Math.abs(s) >= 32767) clip++;
    outPeak = Math.max(outPeak, Math.abs(v));
    outSum += v * v;
    pcm.writeInt16LE(s, i * 2);
  }
  const h = Buffer.alloc(44);
  h.write('RIFF', 0); h.writeUInt32LE(36 + pcm.length, 4); h.write('WAVE', 8); h.write('fmt ', 12);
  h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(1, 22); h.writeUInt32LE(SR, 24);
  h.writeUInt32LE(SR * 2, 28); h.writeUInt16LE(2, 32); h.writeUInt16LE(16, 34); h.write('data', 36); h.writeUInt32LE(pcm.length, 40);
  writeFileSync(new URL(`${name}.wav`, OUT), Buffer.concat([h, pcm]));
  rows.push({name, dur: +(x.length / SR).toFixed(3), peak: +outPeak.toFixed(3), rmsDb: +(20 * Math.log10(Math.sqrt(outSum / x.length))).toFixed(1), clipped: clip});
}
console.table(rows);
